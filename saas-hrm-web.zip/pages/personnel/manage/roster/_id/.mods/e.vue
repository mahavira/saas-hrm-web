<template>
  <div class="wrp">
    b
  </div>
</template>
<script>
export default {
  data () {
    return {
      data: {

      }
    }
  },
  created () {
  },
  methods: {
  }
}
</script>
<style scoped lang="scss">

</style>
