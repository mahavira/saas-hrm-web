<template>
  <div class="intro">
    <img class="headimg" src="" alt="">
    <div class="username">Joe Black</div>
    <div class="number">
      <div>NO.0003</div>
      <div>女 劳务派遣 正式</div>
    </div>
    <div class="info">
      <div>
        <i class="icon-ico_occupation is-primary" /> <span>架构师-B1</span>
      </div>
      <div>
        <i class="el-icon-user-" /> <span>公司经营管理团队</span>
      </div>
      <div>
        <i class="icon-ico_iphone is-primary" /> <span>18834567899</span>
      </div>
      <div>
        <i class="icon-ico_emll is-primary" /> <span>102377489390@163.com</span>
      </div>
    </div>
    <div class="handler">
      <el-button type="primary" size="small" class="is-shadow"><i class="el-icon-refresh" /> 人事异动</el-button><br>
      <el-button type="primary" size="small" class="is-shadow"><i class="el-icon-s-unfold" /> 办理离职</el-button><br>
      <el-button type="default" size="small" class="is-shadow"><i class="icon-ico_delete is-primary" /> 删除员工</el-button>
    </div>
  </div>
</template>
<script>
export default {
  data () {
    return {
    }
  },
  methods: {
  }
}
</script>
