export default [{
  color: 'primary',
  icon: 'icon-ico_edit',
  action: 'detail:edited',
  label: '编辑'
}]
