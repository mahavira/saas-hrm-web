import Vue from 'vue'
import vueMoment from 'vue-moment'

Vue.use(vueMoment)
