// import debounce from 'lodash/debounce'

export default (ctx, inject) => {
  // window.addEventListener('resize', debounce(() => {
  //   inject('xxxxxxxxx', window.innerHeight - 64 - 64 - 80 - 65)
  // }, 1000))
}
