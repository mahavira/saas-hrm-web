export default {
  title: 'HRM平台',
  name: 'hrm',
  themeName: 'blue',
  base: '',
  applicationKey: 'cd1c0b60b5df4910a6c64104a4600493HRMYYGLXT'
}
