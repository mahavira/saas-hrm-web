import baseConfig from './ava.config.js'

export default {
  ...baseConfig,
  files: ['test/e2e/**/*']
}
